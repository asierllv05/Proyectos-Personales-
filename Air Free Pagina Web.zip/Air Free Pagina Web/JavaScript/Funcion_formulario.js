
    function calcularResultado(event) {
        let correctas = 0;
        const respuestas = document.querySelectorAll('input:checked');
        respuestas.forEach(respuesta => {
            switch (respuesta.name) {
                case 'fuente_principal':
                    if (respuesta.value === 'hidraulica') correctas++;
                    break;
                case 'energia_calor':
                    if (respuesta.value === 'geotermica') correctas++;
                    break;
                case 'pais_lider':
                    if (respuesta.value === 'china') correctas++;
                    break;
                case 'recurso_hidraulica':
                    if (respuesta.value === 'agua') correctas++;
                    break;
                case 'no_renovable':
                    if (respuesta.value === 'nuclear') correctas++;
                    break;
            }
        });
        alert(`Tu puntaje es ${correctas} respuestas correctas.`);
    }

# SoundCool.py
# Ejercicio 3.1: Control del Player con Acelerómetro
# Versión Definitiva: Crea el objeto IMU y usa .acceleration

import network
import time
from m5stack import btnA, lcd
import imu                       
from uosc.client import Client

# --- 1. CONFIGURACIÓN WIFI ---
SSID = "GTDM"
PASSWORD = "12345678"
# -----------------------------

# --- 2. CONFIGURACIÓN OSC (MODIFICAR ESTO) ---
server_ip = "192.168.0.190"  # La IP de tu PC (¡revisa ipconfig!)
tx_port = 22203                # Tu puerto (ej. 22207)
# ----------------------------------------------

# --- 3. CONFIGURACIÓN APP ---
ALPHA = 0.1 # Factor de suavizado para el acelerómetro
# ----------------------------

# --- Función para conectar/revisar WiFi ---
wlan = network.WLAN(network.STA_IF)

def connect_wifi():
    if not wlan.isconnected():
        print("Conectando a WiFi...")
        lcd.print("Conectando a WiFi...", 0, 0)
        wlan.active(True)
        wlan.connect(SSID, PASSWORD)
        
        start_time = time.ticks_ms()
        while not wlan.isconnected():
            time.sleep_ms(100)
            if time.ticks_diff(time.ticks_ms(), start_time) > 10000:
                print("Error: No se pudo conectar a la WiFi")
                lcd.print("Error WiFi", 0, 15)
                return False
                
    wifi_config = wlan.ifconfig()
    wifi_ip = wifi_config[0]
    print("Conectado con IP: {}".format(wifi_ip))
    lcd.clear()
    lcd.print("IP: {}".format(wifi_ip), 0, 0)
    return True

# --- Conexión Inicial ---
if not connect_wifi():
    raise Exception("No hay conexión WiFi")

# --- Inicializar OSC, IMU y variables ---
osc = Client(server_ip, tx_port)
imu_sensor = imu.IMU() # <-- CORRECCIÓN 1: Creamos el objeto IMU

smoothed_x = 0.0
smoothed_y = 0.0
is_playing = False 

print("Enviando OSC a {}:{}".format(server_ip, tx_port))
lcd.print("OSC -> {}:{}".format(server_ip, tx_port), 0, 15)
lcd.print("Controlando Player...", 0, 45)

# --- Bucle Principal ---
while True:
    try:
        # 1. Revisar WiFi
        if not wlan.isconnected():
            print("WiFi perdida. Reconectando...")
            connect_wifi()
            time.sleep(2)
            continue

        # 2. Leer y suavizar Acelerómetro
        #    CORRECCIÓN 2: Leemos .acceleration DESDE el objeto imu_sensor
        acc_x, acc_y, acc_z = imu_sensor.acceleration 
        
        smoothed_x = (ALPHA * acc_x) + ((1 - ALPHA) * smoothed_x)
        smoothed_y = (ALPHA * acc_y) + ((1 - ALPHA) * smoothed_y)
        
        # 3. Escalar valores (-1 a +1) -> (0 a 1)
        val_speed = (smoothed_x + 1.0) / 2.0
        val_vol = (-smoothed_y + 1.0) / 2.0
        
        val_speed = max(0.0, min(1.0, val_speed))
        val_vol = max(0.0, min(1.0, val_vol))
        
        # 4. Enviar mensajes OSC
        osc.send("/1/fader1", val_speed) # Controla Speed
        osc.send("/1/fader3", val_vol)   # Controla Volumen
        
        # 5. Control Botón A (Play/Stop)
        if btnA.wasPressed():
            is_playing = not is_playing
            
            if is_playing:
                print("Enviando PLAY")
                lcd.print("PLAY", 280, 220, lcd.GREEN)
                osc.send("/1/push1", 1.0) # Mensaje de Play
            else:
                print("Enviando STOP")
                lcd.print("STOP", 280, 220, lcd.RED)
                osc.send("/1/push2", 1.0) # Mensaje de Stop
        
        # 6. Mostrar en LCD (opcional)
        lcd.print("Speed (X): {:.2f}".format(val_speed), 0, 60)
        lcd.print("Vol (Y):   {:.2f}".format(val_vol), 0, 75)
        
        time.sleep_ms(20) 
        
    except Exception as e:
        print("Error en bucle: {}".format(e))
        time.sleep(2)
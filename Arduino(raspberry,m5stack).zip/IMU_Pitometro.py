from m5stack import lcd, speaker
import machine
import time
import neopixel  

TRIG_PIN = 26
ECHO_PIN = 36
VEL_SONIDO = 343.0
DIST_MAX = 3.0

# LCD
lcd.clear(0x000000)
lcd.font(lcd.FONT_DejaVu72)

# Sensor
trig = machine.Pin(TRIG_PIN, machine.Pin.OUT)
echo = machine.Pin(ECHO_PIN, machine.Pin.IN)

# LEDs laterales — prueba pin 15, 27 o 32 según tu base
LED_PIN = 15
NUM_LEDS = 10
np = neopixel.NeoPixel(machine.Pin(LED_PIN), NUM_LEDS)

def medir_distancia():
    trig.value(0)
    time.sleep_us(2)
    trig.value(1)
    time.sleep_us(10)
    trig.value(0)
    inicio = time.ticks_us()
    while echo.value() == 0:
        if time.ticks_diff(time.ticks_us(), inicio) > 30000:
            return None
    subida = time.ticks_us()
    while echo.value() == 1:
        if time.ticks_diff(time.ticks_us(), subida) > 30000:
            return None
    bajada = time.ticks_us()
    duracion = time.ticks_diff(bajada, subida)
    distancia = (duracion * VEL_SONIDO) / 2_000_000
    return distancia

def mostrar_en_pantalla(dist):
    lcd.clear(0x000000)
    if dist is None or dist > DIST_MAX:
        lcd.print("----", 20, 60, 0xFFFFFF)
        return 0x000000
    cm = dist * 100
    if cm <= 10:
        color = 0xFF0000
    elif cm <= 25:
        color = 0xFF8000
    elif cm <= 50:
        color = 0xFFFF00
    elif cm <= 100:
        color = 0x00FF00
    else:
        color = 0xFFFFFF
    texto = "{:.2f}m".format(dist)
    lcd.print(texto, 20, 60, color)
    return color

def encender_leds(color):
    r = (color >> 16) & 0xFF
    g = (color >> 8) & 0xFF
    b = color & 0xFF
    for i in range(NUM_LEDS):
        np[i] = (r, g, b)
    np.write()

def hacer_beep(dist):
    if dist is None or dist > 3.0:
        return
    cm = dist * 100
    if cm <= 10:
        tono, pausa = 800, 0.1
    elif cm <= 25:
        tono, pausa = 700, 0.25
    elif cm <= 50:
        tono, pausa = 600, 0.5
    elif cm <= 100:
        tono, pausa = 500, 1.0
    else:
        return
    speaker.tone(tono, 20)
    time.sleep(pausa)

while True:
    try:
        d = medir_distancia()
        color = mostrar_en_pantalla(d)
        encender_leds(color)
        hacer_beep(d)
        time.sleep(0.05)
    except KeyboardInterrupt:
        lcd.clear()
        break

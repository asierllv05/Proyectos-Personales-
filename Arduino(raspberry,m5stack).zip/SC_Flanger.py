# SC_Flanger.py
# Ejercicio 3.4 Opcional: Control de dos módulos en dos puertos

import wifiCfg
from uosc.client import Client
import imu, time
# (No necesitamos el botón A para este ejercicio)

# Conexión WiFi
print("Conectando...")
wifiCfg.connect("GTDM", "12345678", 30000, True)
if wifiCfg.wlan_sta.isconnected():
    print("Conectado con IP:", wifiCfg.wlan_sta.ifconfig()[0])
else:
    print("No conectado")
    raise RuntimeError("No se pudo conectar al WiFi")

# --- Configuración OSC (MODIFICADA) ---
server_ip = "192.168.0.190"  # IP del PC con SoundCool

# ¡Dos puertos diferentes!
tx_port_delay = 22203        # Puerto para el Delay
tx_port_eq = 22204           # Puerto para el PeakNotch
# ------------------------------------

# --- Clientes OSC (MODIFICADO) ---
# ¡Dos clientes diferentes!
osc_delay = Client(server_ip, tx_port_delay)
osc_eq = Client(server_ip, tx_port_eq)

print("OSC Delay -> {}:{}".format(server_ip, tx_port_delay))
print("OSC EQ    -> {}:{}".format(server_ip, tx_port_eq))

# Inicializar IMU
imu0 = imu.IMU()

# Variables para suavizado
alpha = 0.2
smooth_x, smooth_y = 0, 0

while True:
    ax, ay, az = imu0.acceleration
    # Suavizado
    smooth_x = alpha * ax + (1 - alpha) * smooth_x
    smooth_y = alpha * ay + (1 - alpha) * smooth_y

    # Escalar acelerómetro (-1..1) -> (0..1)
    
    # Eje X -> Controla Delay
    val_delay = max(0, min(1, (smooth_x + 1) / 2))
    
    # Eje Y -> Controla EQ
    # (Usando la fórmula invertida del ejercicio anterior para el control tipo "moto")
    val_eq = max(0, min(1, (-smooth_y + 1) / 2))

    # --- Enviar valores OSC (MODIFICADO) ---
    
    # 1. Enviar al Puerto 1 (Delay)
    # Asumimos que el fader1 del Delay controla el tiempo de retardo
    osc_delay.send("/1/fader1", val_delay)
    
    # 2. Enviar al Puerto 2 (EQ)
    # Asumimos que el fader1 del PeakNotch controla la frecuencia
    osc_eq.send("/1/fader1", val_eq)

    # Imprimimos ambos valores para depuración
    print("Delay (X): {:.2f} | EQ (Y): {:.2f}".format(val_delay, val_eq))

    time.sleep(0.1)
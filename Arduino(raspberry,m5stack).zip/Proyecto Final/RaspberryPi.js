const express = require('express');
const app = express();
const http = require('http').createServer(app);
const io = require('socket.io')(http);
const dgram = require('dgram');
const fs = require('fs');
const readline = require('readline');

// --- CONFIGURACIÓN ---
const WEB_PORT = 3000;
const UDP_PORT = 4444;

// Estado del Jugador (Tamagotchi)
let posX = 50; // Posición % X
let posY = 50; // Posición % Y

app.use(express.static(__dirname + '/interfaz'));

app.get('/', (req, res) => {
    // Asegúrate de que el archivo html se llame 'interfaz.html'
    res.sendFile(__dirname + '/interfaz.html');
});

// --- 1. SOCKET WEB (Comunicación con el Navegador) ---
io.on('connection', (socket) => {
    console.log('🟢 Web conectada');
    // Enviar posición inicial al conectar
    socket.emit('posicion_update', { x: posX, y: posY });
});

// --- 2. SERVIDOR UDP (Recibir datos del M5Stack) ---
const udpServer = dgram.createSocket('udp4');
udpServer.on('message', (msg) => {
    try {
        // El M5 envía un JSON string, lo parseamos y lo enviamos a la web
        const m5Data = JSON.parse(msg.toString());
        io.emit('m5_update', m5Data);
    } catch (e) {
        console.error("Error parseando JSON del M5Stack");
    }
});
udpServer.bind(UDP_PORT, () => console.log(`👂 UDP escuchando M5Stack en puerto ${UDP_PORT}`));

// --- 3. LOGICA DE MOVIMIENTO (Común para Joystick y Teclado) ---
function moverJugador(direccion) {
    const paso = 5; // Cuánto se mueve por pulsación (%)
    
    switch(direccion) {
        case 'up':    posY = Math.max(0, posY - paso); break;
        case 'down':  posY = Math.min(100, posY + paso); break;
        case 'left':  posX = Math.max(0, posX - paso); break;
        case 'right': posX = Math.min(100, posX + paso); break;
    }
    
    // Enviamos la nueva posición a la web
    io.emit('posicion_update', { x: posX, y: posY });
}

// --- 4. DRIVER JOYSTICK SENSE HAT (Lectura directa de hardware) ---
function buscarJoystick() {
    console.log("🔎 Buscando Joystick Sense HAT...");
    const inputDir = '/sys/class/input/';
    
    try {
        const devices = fs.readdirSync(inputDir);
        for (const dev of devices) {
            if (dev.startsWith('event')) {
                const namePath = inputDir + dev + '/device/name';
                if (fs.existsSync(namePath)) {
                    const name = fs.readFileSync(namePath, 'utf8').trim();
                    // El nombre técnico suele ser 'Raspberry Pi Sense HAT Joystick'
                    if (name.includes('Sense HAT Joystick')) {
                        console.log(`✅ JOYSTICK ENCONTRADO en: /dev/input/${dev}`);
                        leerJoystick('/dev/input/' + dev);
                        return;
                    }
                }
            }
        }
        console.log("❌ No se encontró Joystick físico (¿Estás usando SenseHAT?).");
    } catch (e) {
        console.error("Error buscando dispositivos:", e.message);
    }
}

function leerJoystick(path) {
    const stream = fs.createReadStream(path);
    
    // BUFFER PARSING SEGURO
    // Evento Linux Input: [TIME 8-16b] [TYPE 2b] [CODE 2b] [VALUE 4b]
    stream.on('data', (buffer) => {
        // Escaneamos el buffer buscando eventos de tecla (Type = 1)
        for (let i = 0; i < buffer.length - 8; i++) {
            try {
                // Leemos como enteros Little Endian
                const type = buffer.readUInt16LE(i);
                const code = buffer.readUInt16LE(i + 2);
                const value = buffer.readInt32LE(i + 4);

                // Type 1 = EV_KEY (Tecla)
                if (type === 1) {
                    // Value 1 = Press, 2 = Hold (ignora 0 release)
                    if (value === 1 || value === 2) {
                        if (code === 103) moverJugador('up');    // Flecha Arriba
                        if (code === 108) moverJugador('down');  // Flecha Abajo
                        if (code === 105) moverJugador('left');  // Flecha Izquierda
                        if (code === 106) moverJugador('right'); // Flecha Derecha
                        if (code === 28)  console.log("🔘 Click Central"); // Enter
                        
                        i += 8; // Saltamos bytes procesados para eficiencia
                    }
                }
            } catch(err) {}
        }
    });
    
    stream.on('error', (err) => {
        if(err.code === 'EACCES') console.log("⚠️ PERMISO DENEGADO: Usa 'sudo node app.js' para leer el Joystick.");
    });
}

// Iniciar búsqueda de Joystick solo si somos root (sudo)
if (process.getuid && process.getuid() === 0) {
    buscarJoystick();
} else {
    console.log("⚠️ NO ERES ROOT: El Joystick físico no funcionará (usa sudo).");
}

// --- 5. TECLADO DEL PC (WASD y Flechas) ---
// Esto permite controlar el juego desde la terminal SSH o teclado USB
readline.emitKeypressEvents(process.stdin);
if (process.stdin.isTTY) process.stdin.setRawMode(true);

process.stdin.on('keypress', (str, key) => {
    if (key.ctrl && key.name === 'c') process.exit(); // Salir con Ctrl+C
    
    if (['w', 'up'].includes(key.name)) moverJugador('up');
    if (['s', 'down'].includes(key.name)) moverJugador('down');
    if (['a', 'left'].includes(key.name)) moverJugador('left');
    if (['d', 'right'].includes(key.name)) moverJugador('right');
});

// --- ARRANCAR SERVIDOR ---
http.listen(WEB_PORT, () => {
    console.log(`🚀 Servidor listo: http://localhost:${WEB_PORT}`);
    console.log(`⌨️  Puedes usar WASD para mover el Tamagotchi.`);
});
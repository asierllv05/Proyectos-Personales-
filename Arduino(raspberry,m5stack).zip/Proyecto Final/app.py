from flask import Flask, render_template, request
from flask_socketio import SocketIO
from sense_hat import SenseHat
import threading
import time

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secreto'
socketio = SocketIO(app, cors_allowed_origins="*")

# ESTADO GLOBAL
estado_global = {
    "cara": "normal", 
    "temp": 0
}

# SenseHAT
try:
    sense = SenseHat()
    sense.clear()
except:
    sense = None

# Hilo Sensores Raspberry
def leer_sensores():
    while True:
        if sense:
            # Joystick
            for event in sense.stick.get_events():
                if event.action == "pressed":
                    socketio.emit('joystick_evento', {'direction': event.direction})
            
            # Temperatura
            try:
                temp = sense.get_temperature()
                if temp and 0 < temp < 80:
                    estado_global["temp"] = round(temp, 1)
                    # Lógica simple de temperatura
                    if estado_global["cara"] in ["normal", "calor", "frio"]:
                        if temp > 30: estado_global["cara"] = "calor"
                        elif temp < 20: estado_global["cara"] = "frio"
                        else: estado_global["cara"] = "normal"
                    
                    socketio.emit('estado_update', estado_global)
            except: pass
        time.sleep(0.5)

hilo = threading.Thread(target=leer_sensores)
hilo.daemon = True
hilo.start()

# RUTAS
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/status', methods=['GET'])
def enviar_status():
    return estado_global["cara"], 200

@app.route('/api/accion', methods=['POST'])
def recibir_accion():
    # IMPRIMIR EN CONSOLA PARA VER SI LLEGA
    tipo = request.form.get('tipo')
    print(f" >>> RECIBIDO DEL M5: {tipo}")
    
    if tipo == 'agitar':
        estado_global["cara"] = "mareado"
    elif tipo == 'botonA':
        estado_global["cara"] = "comiendo"
    elif tipo == 'botonB':
        estado_global["cara"] = "feliz"
    elif tipo == 'botonC':
        estado_global["cara"] = "durmiendo"

    socketio.emit('estado_update', estado_global)
    
    # Recuperar normalidad
    def recuperar():
        time.sleep(3)
        estado_global["cara"] = "normal"
        socketio.emit('estado_update', estado_global)
    threading.Thread(target=recuperar).start()

    return "OK", 200

if __name__ == '__main__':
    print("--- SERVIDOR LISTO. ESCUCHANDO... ---")
    socketio.run(app, host='0.0.0.0', port=5000)
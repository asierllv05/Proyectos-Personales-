# imu_text.py
from m5stack import lcd, btnA, btnB, btnC
import imu
import utime
import math

# -----------------------------
# 1️⃣ Configuración inicial LCD
# -----------------------------
SCREEN_WIDTH = 320
SCREEN_HEIGHT = 240
SCREEN_COLOR = lcd.BLACK

lcd.clear(SCREEN_COLOR)
lcd.font(lcd.FONT_DejaVu18, transparent=False)
lcd.sprite_create(SCREEN_WIDTH, SCREEN_HEIGHT, lcd.SPRITE_8BIT)
lcd.sprite_select()

# Mensaje inicial con logo o título
lcd.clear(SCREEN_COLOR)
lcd.font(lcd.FONT_DejaVu24, transparent=False)
lcd.print("INTERACCION", lcd.CENTER, 30, lcd.RED)
lcd.font(lcd.FONT_DejaVu18, transparent=False)
lcd.print("G  T  D  M", lcd.CENTER, 80, lcd.WHITE)
lcd.sprite_show(0, 0)
utime.sleep(2)

# -----------------------------
# 2️⃣ Crear objeto IMU
# -----------------------------
mpu = imu.IMU()

# -----------------------------
# 3️⃣ Funciones auxiliares
# -----------------------------
def mostrar_lcd(x, y, texto, color=lcd.WHITE, font_size=lcd.FONT_DejaVu18):
    lcd.font(font_size, transparent=False)
    lcd.sprite_select()
    lcd.print(texto, x, y, color)
    lcd.sprite_show(0, 0)

def format_vector(v):
    return "{:.2f}, {:.2f}, {:.2f}".format(float(v[0]), float(v[1]), float(v[2]))

# Filtro paso-bajo IIR
alpha = 0.3
def smooth(prev, current):
    return tuple(alpha*c + (1-alpha)*p for p,c in zip(prev,current))

# Calibración de offsets
def calibrar_offset(muestras=20):
    lcd.clear(SCREEN_COLOR)
    mostrar_lcd(lcd.CENTER, 50, "LECTURA OFFSETS", lcd.GREEN, lcd.FONT_DejaVu24)
    mostrar_lcd(lcd.CENTER, 100, "M5STACK EN LA MESA", lcd.GREEN)
    mostrar_lcd(lcd.CENTER, 130, "btnA para empezar", lcd.GREEN)
    
    print("Calibrando... Mantenga el M5Stack quieto")
    while not btnA.isPressed():
        utime.sleep_ms(50)
    
    utime.sleep_ms(250)  # Anti-rebote
    
    sum_acc = [0.0, 0.0, 0.0]
    sum_gyro = [0.0, 0.0, 0.0]
    
    for _ in range(muestras):
        acc = mpu.acceleration
        gyro = mpu.gyro
        sum_acc = [s+a for s,a in zip(sum_acc, acc)]
        sum_gyro = [s+g for s,g in zip(sum_gyro, gyro)]
        utime.sleep_ms(50)
    
    offset_acc = [s/muestras for s in sum_acc]
    offset_gyro = [s/muestras for s in sum_gyro]
    
    print("Offset calculado:", offset_acc, offset_gyro)
    return offset_acc, offset_gyro

# Cálculo de ángulos tilt opcional
def tilt_angles(acc):
    ax, ay, az = acc
    angle_x = math.degrees(math.atan2(ax, az))
    angle_y = math.degrees(math.atan2(ay, az))
    angle_3d = math.degrees(math.atan2(math.sqrt(ax*ax + ay*ay), az))
    return angle_x, angle_y, angle_3d

# -----------------------------
# 4️⃣ Inicialización valores
# -----------------------------
smoothed_acc = mpu.acceleration
smoothed_gyro = mpu.gyro
offset_acc = [0.0, 0.0, 0.0]
offset_gyro = [0.0, 0.0, 0.0]

# -----------------------------
# 5️⃣ Loop principal
# -----------------------------
while True:
    # Calibración al pulsar btnA
    if btnA.isPressed():
        utime.sleep_ms(250)  # anti-rebote
        offset_acc, offset_gyro = calibrar_offset()

    # Leer sensores y compensar offsets
    acc = [a - o for a,o in zip(mpu.acceleration, offset_acc)]
    gyro = [g - o for g,o in zip(mpu.gyro, offset_gyro)]
    ypr = mpu.ypr  # ya incluye smoothing interno

    # Aplicar suavizado paso-bajo
    smoothed_acc = smooth(smoothed_acc, acc)
    smoothed_gyro = smooth(smoothed_gyro, gyro)

    # Calcular ángulos tilt
    angle_x, angle_y, angle_3d = tilt_angles(smoothed_acc)

    # -----------------------------
    # Mostrar en consola
    # -----------------------------
    print("ACC:", format_vector(smoothed_acc))
    print("GYRO:", format_vector(smoothed_gyro))
    print("YPR:", format_vector(ypr))
    print("TiltX:{:.2f}, TiltY:{:.2f}, Tilt3D:{:.2f}".format(angle_x, angle_y, angle_3d))
    print("-----------------------------------")

    # -----------------------------
    # Mostrar en LCD
    # -----------------------------
    lcd.clear(SCREEN_COLOR)
    lcd.sprite_select()
    lcd.font(lcd.FONT_DejaVu18, transparent=False)
    
    lcd.print("IMU_TEXT", lcd.CENTER-40, 10, lcd.GREEN)
    
    lcd.print("a : " + format_vector(acc), 10, 50, lcd.CYAN)
    lcd.print("as: " + format_vector(smoothed_acc), 10, 70, lcd.CYAN)
    lcd.print("g : " + format_vector(gyro), 10, 90, lcd.YELLOW)
    lcd.print("gs: " + format_vector(smoothed_gyro), 10, 110, lcd.YELLOW)
    lcd.print("ypr: " + format_vector(ypr), 10, 130, lcd.WHITE)
    lcd.print("{:.1f}, {:.1f}, {:.1f}".format(angle_x, angle_y, angle_3d), 10, 150, lcd.GREEN)
    
    lcd.sprite_show(0, 0)

    utime.sleep_ms(50)
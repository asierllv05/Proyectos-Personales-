# Este es el código para fader_4.py
from m5stack import lcd, btnA, btnC, speaker
import socket
import imu
import utime
import math
import wifiCfg
from uosc.client import Client  # Importamos el cliente de la librería
import time

print("Conectando...")
wifiCfg.connect("GTDM", "12345678", 30000, True)

if wifiCfg.wlan_sta.isconnected():
    wifi_ip = ""
    wifi_config = wifiCfg.wlan_sta.ifconfig()
    if wifi_config is not None:
        wifi_ip = wifi_config[0]
    print("Conectado con IP:", wifi_ip)
else:
    print("No conectado")
    # Si no conecta, detenemos el script
    raise RuntimeError("No se pudo conectar al WiFi")


# --- ¡ASEGÚRATE DE QUE ESTA IP ES CORRECTA! ---
# Debe ser la IP de tu ordenador en la red WiFi "GTDM"
server_ip = "192.168.0.190"
tx_port = 22203                    # <-- Este puerto debe coincidir con el "Receive Port" en TouchOSC
# -----------------------------------

# Creamos el objeto cliente OSC
# La librería se encarga del socket internamente
osc = Client(server_ip, tx_port)

print("Enviando a {}:{}...".format(server_ip, tx_port))

# Dos variables: una que sube y otra que baja
valor_subiendo = 0.0
valor_bajando = 1.0

try:
    while True:
        
        # --- ¡CÓDIGO CORREGIDO AQUÍ! ---
        
        # 1. Enviar a los faders 1 y 2 el valor que sube
        # Enviamos a cada dirección OSC por separado
        osc.send("/fader[1-2]", valor_subiendo)
        
        # 2. Enviar a los faders 3 y 4 el valor que baja
        osc.send("/fader[3-4]", valor_bajando)

        # -----------------------------------

        print("Faders[1-2]: {:.1f} | Faders[3-4]: {:.1f}".format(valor_subiendo, valor_bajando))
        
        # --- Actualizamos los valores ---
        
        # Valor que sube
        valor_subiendo = valor_subiendo + 0.1
        if valor_subiendo > 1.0:
            valor_subiendo = 0.0
            
        # Valor que baja
        valor_bajando = valor_bajando - 0.1
        if valor_bajando < 0.0:
            valor_bajando = 1.0

        # Esperamos 100 milisegundos
        time.sleep_ms(100)

except KeyboardInterrupt:
    print("Detenido por el usuario.")
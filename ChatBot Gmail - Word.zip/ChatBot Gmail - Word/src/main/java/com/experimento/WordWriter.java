package com.experimento;

import org.apache.poi.xwpf.usermodel.*;
import java.io.FileOutputStream;
import java.util.List;

public class WordWriter {

    public void guardarResumenes(List<String> resumenes) {
        try (XWPFDocument document = new XWPFDocument()) {

            // Crear Título
            XWPFParagraph titulo = document.createParagraph();
            titulo.setAlignment(ParagraphAlignment.CENTER);
            XWPFRun runTitulo = titulo.createRun();
            runTitulo.setText("Resumen de Correos Recibidos");
            runTitulo.setBold(true);
            runTitulo.setFontSize(24);
            runTitulo.setColor("0000FF"); // Azul

            // Añadir espacio
            document.createParagraph();

            // Escribir cada resumen en el documento
            for (int i = 0; i < resumenes.size(); i++) {
                XWPFParagraph p = document.createParagraph();
                XWPFRun r = p.createRun();

                r.setText("✉️ " + resumenes.get(i));
                r.setFontSize(12);

                // Salto de línea entre resúmenes
                p.setSpacingAfter(300);
            }

            // Guardar el archivo en la carpeta del proyecto
            String nombreArchivo = "Resumen_Emails.docx";
            FileOutputStream out = new FileOutputStream(nombreArchivo);
            document.write(out);
            out.close();

            System.out.println("✅ ¡Éxito! Archivo guardado como: " + nombreArchivo);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
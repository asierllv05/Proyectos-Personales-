package com.experimento;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AISummarizer {

    // No necesitamos API Keys aquí porque el cerebro es tu código
    public AISummarizer(String apiKey) {
        // El constructor se queda vacío o simplemente ignora la key
    }

    public String resumir(String textoEmail) {
        if (textoEmail == null || textoEmail.isEmpty()) return "Correo vacío.";

        // 1. Limpieza básica
        String texto = textoEmail.replace("\n", " ").trim();

        // 2. Dividir el texto en frases (usando el punto como separador)
        String[] frases = texto.split("\\.");

        if (frases.length == 0) return texto;

        StringBuilder resumen = new StringBuilder();

        // REGLA 1: La primera frase suele ser la introducción importante
        if (frases.length > 0) {
            resumen.append(frases[0].trim()).append(". ");
        }

        // REGLA 2: Buscar frases con palabras clave de acción
        // Palabras que indican importancia en un email laboral
        String[] palabrasClave = {"urgente", "reunión", "adjunto", "pago", "fecha", "envío", "error", "importante", "mañana", "hoy"};

        boolean encontradaExtra = false;

        // Buscamos en el resto de frases (saltando la primera)
        for (int i = 1; i < frases.length; i++) {
            String fraseActual = frases[i].toLowerCase();

            for (String palabra : palabrasClave) {
                if (fraseActual.contains(palabra)) {
                    // Si encontramos una palabra clave, añadimos esa frase al resumen
                    resumen.append(frases[i].trim()).append(". ");
                    encontradaExtra = true;
                    break; // Pasamos a la siguiente frase para no repetir
                }
            }
            // Limitamos para que el resumen no sea gigante (máximo 2 frases extra)
            if (resumen.length() > 300) break;
        }

        // REGLA 3: Si no encontró nada clave, y el texto es largo, añadimos la segunda frase por si acaso
        if (!encontradaExtra && frases.length > 1) {
            resumen.append(frases[1].trim()).append(".");
        }

        return "⚡ (Local): " + resumen.toString();
    }
}
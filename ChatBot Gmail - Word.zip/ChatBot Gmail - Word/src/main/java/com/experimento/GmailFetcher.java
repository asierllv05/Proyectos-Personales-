package com.experimento;

import jakarta.mail.*;
import jakarta.mail.internet.MimeMultipart;
import org.jsoup.Jsoup;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class GmailFetcher {

    private String email;
    private String password;

    public GmailFetcher(String email, String password) {
        this.email = email;
        this.password = password;
    }

    public List<String> leerUltimosCorreos(int cantidad) {
        List<String> textosCorreos = new ArrayList<>();
        // Configuración para conectar a Gmail por IMAP
        Properties props = new Properties();
        props.put("mail.store.protocol", "imaps");
        props.put("mail.imaps.host", "imap.gmail.com");
        props.put("mail.imaps.port", "993");

        try {
            Session session = Session.getDefaultInstance(props);
            Store store = session.getStore("imaps");
            // Conectamos usando tu email y la contraseña de aplicación
            store.connect("imap.gmail.com", email, password);

            Folder inbox = store.getFolder("INBOX");
            inbox.open(Folder.READ_ONLY);

            int totalMensajes = inbox.getMessageCount();
            int inicio = Math.max(1, totalMensajes - cantidad + 1);

            // Obtenemos los mensajes
            Message[] messages = inbox.getMessages(inicio, totalMensajes);
            System.out.println("📥 He encontrado " + messages.length + " correos nuevos.");

            for (Message message : messages) {
                try {
                    String contenidoBruto = getTextFromMessage(message);
                    // Limpiamos el HTML para dejar solo texto
                    String textoLimpio = Jsoup.parse(contenidoBruto).text();
                    textosCorreos.add("ASUNTO: " + message.getSubject() + "\nCUERPO: " + textoLimpio);
                } catch (Exception ex) {
                    System.out.println("⚠️ No pude leer un correo: " + ex.getMessage());
                }
            }

            inbox.close(false);
            store.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return textosCorreos;
    }

    // Método auxiliar para extraer texto aunque el correo sea complejo (HTML/Adjuntos)
    private String getTextFromMessage(Message message) throws Exception {
        if (message.isMimeType("text/plain")) {
            return message.getContent().toString();
        } else if (message.isMimeType("multipart/*")) {
            MimeMultipart mimeMultipart = (MimeMultipart) message.getContent();
            return getTextFromMimeMultipart(mimeMultipart);
        }
        return "";
    }

    private String getTextFromMimeMultipart(MimeMultipart mimeMultipart) throws Exception {
        StringBuilder result = new StringBuilder();
        int count = mimeMultipart.getCount();
        for (int i = 0; i < count; i++) {
            BodyPart bodyPart = mimeMultipart.getBodyPart(i);
            if (bodyPart.isMimeType("text/plain")) {
                result.append(bodyPart.getContent());
            } else if (bodyPart.isMimeType("text/html")) {
                String html = (String) bodyPart.getContent();
                result.append(html);
            } else if (bodyPart.getContent() instanceof MimeMultipart) {
                result.append(getTextFromMimeMultipart((MimeMultipart) bodyPart.getContent()));
            }
        }
        return result.toString();
    }
}

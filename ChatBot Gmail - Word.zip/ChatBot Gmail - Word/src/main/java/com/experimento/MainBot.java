package com.experimento;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MainBot {

    // ==========================================
    // ⚙️ TUS CREDENCIALES (Rellena esto)
    // ==========================================

    // 1. Tu correo de Gmail completo
    private static final String GMAIL_USER = "correo@gmail.com";

    // 2. Tu "Contraseña de Aplicación" (NO la contraseña normal de Gmail)
    // Créala aquí: https://myaccount.google.com/apppasswords
    private static final String GMAIL_APP_PASSWORD = ".....";

    // 3. Tu API Key de OpenAI (empieza por sk-...)
    // Consíguela aquí: https://platform.openai.com/api-keys
    private static final String OPENAI_API_KEY = "#";

    // ==========================================

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("\n🤖 CHATBOT: Hola. Soy tu asistente de correo.");
        System.out.println("👉 Escribe 'resumir 3' para procesar tus últimos 3 emails.");
        System.out.println("👉 Escribe 'salir' para terminar.");

        while (true) {
            System.out.print("\n> ");
            String input = scanner.nextLine();

            if (input.startsWith("resumir")) {
                try {
                    // Averiguar cuántos correos quiere el usuario
                    String[] partes = input.split(" ");
                    int cantidad = partes.length > 1 ? Integer.parseInt(partes[1]) : 3;

                    System.out.println("⏳ Conectando a Gmail...");
                    GmailFetcher fetcher = new GmailFetcher(GMAIL_USER, GMAIL_APP_PASSWORD);
                    List<String> correosBrutos = fetcher.leerUltimosCorreos(cantidad);

                    if (correosBrutos.isEmpty()) {
                        System.out.println("⚠️ No encontré correos o hubo un error de conexión.");
                        continue;
                    }

                    System.out.println("🧠 Analizando con Inteligencia Artificial...");
                    AISummarizer cerebro = new AISummarizer(OPENAI_API_KEY);
                    List<String> resumenesFinales = new ArrayList<>();

                    for (String rawEmail : correosBrutos) {
                        String resumen = cerebro.resumir(rawEmail);
                        System.out.println("   -> " + resumen);
                        resumenesFinales.add(resumen);
                    }

                    System.out.println("💾 Guardando en Word...");
                    WordWriter escritor = new WordWriter();
                    escritor.guardarResumenes(resumenesFinales);

                } catch (Exception e) {
                    System.out.println("❌ Ocurrió un error: " + e.getMessage());
                    e.printStackTrace();
                }

            } else if (input.equalsIgnoreCase("salir")) {
                System.out.println("👋 ¡Hasta luego!");
                break;
            } else {
                System.out.println("🤖 No entiendo. Prueba con 'resumir 5'.");
            }
        }
    }
}
